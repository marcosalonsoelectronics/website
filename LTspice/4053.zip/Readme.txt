Copy 4053.asy into ./sym
Copy 4053.sub into ./sub

Use .lib 4053.sub in your LTspice schematic 