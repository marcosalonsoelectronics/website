Copy 4532.asy into ./sym
Copy 4532.sub into ./sub

Use .lib 4532.sub in your LTspice schematic if necessary